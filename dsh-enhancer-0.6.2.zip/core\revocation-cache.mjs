import fs from "node:fs";
import path from "node:path";

// 只缓存最近一次「验签通过」的原始清单字节（{head, sig}）。
// 读取方必须重新验签 —— 缓存不是信任来源，只是离线时的传输副本。
export function cachePath(storeDir) {
  return path.join(storeDir, "revocations-cache.json");
}

export function readCachedPayload(storeDir) {
  try {
    const parsed = JSON.parse(fs.readFileSync(cachePath(storeDir), "utf8"));
    if (!parsed || typeof parsed.head !== "string" || typeof parsed.sig !== "string") return null;
    return { head: parsed.head, sig: parsed.sig, cachedAt: parsed.cachedAt ?? null };
  } catch {
    return null;
  }
}

export function writeCachedPayload(storeDir, payload) {
  try {
    fs.mkdirSync(storeDir, { recursive: true });
    const target = cachePath(storeDir);
    const tmp = `${target}.${process.pid}.tmp`;
    fs.writeFileSync(
      tmp,
      `${JSON.stringify({ head: payload.head, sig: payload.sig, cachedAt: new Date().toISOString() }, null, 2)}\n`,
    );
    fs.renameSync(tmp, target);
    return true;
  } catch {
    return false;
  }
}

export function clearCachedPayload(storeDir) {
  try {
    fs.rmSync(cachePath(storeDir), { force: true });
    return true;
  } catch {
    return false;
  }
}
