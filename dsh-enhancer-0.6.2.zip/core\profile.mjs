import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { profileRows, normalizeEdition } from "./patches.mjs";
import { storeDir } from "./patcher.mjs";

const BEGIN = "# >>> dsh-enhancer managed block (do not edit) >>>";
const END = "# <<< dsh-enhancer managed block <<<";

const sha256 = (buf) => crypto.createHash("sha256").update(buf).digest("hex");

export function renderBlock(edition = "standard") {
  const kind = normalizeEdition(edition);
  return `${BEGIN}\n# edition: ${kind}\n${profileRows(kind)}\n${END}\n`;
}

export function profileFile({ dir }) {
  return path.join(dir, "cordis.patch.yml");
}

function ledgerFile() {
  return path.join(storeDir(), "profile-ledger.json");
}

function readLedger() {
  try {
    return JSON.parse(fs.readFileSync(ledgerFile(), "utf8"));
  } catch {
    return {};
  }
}

function writeLedger(data) {
  fs.mkdirSync(storeDir(), { recursive: true });
  const tmp = `${ledgerFile()}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, ledgerFile());
}

function writeAtomic(file, buf) {
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, buf);
  fs.renameSync(tmp, file);
}

function upsert(text, edition) {
  const begin = text.indexOf(BEGIN);
  const end = text.indexOf(END);
  if (begin >= 0 && end > begin) {
    const rest = text.slice(end + END.length).replace(/^\n/, "");
    return text.slice(0, begin) + renderBlock(edition) + rest;
  }
  const lead = text.length === 0 || text.endsWith("\n") ? text : `${text}\n`;
  return `${lead}\n${renderBlock(edition)}`;
}

export function inspectProfile({ dir }) {
  const file = profileFile({ dir });
  if (!fs.existsSync(file)) return { ok: false, reason: "profile-missing", file };
  const text = fs.readFileSync(file, "utf8");
  const begin = text.indexOf(BEGIN);
  const end = text.indexOf(END);
  const hasBlock = begin >= 0 && end > begin;
  const body = hasBlock ? text.slice(begin, end + END.length) : "";
  const editionMatch = hasBlock ? body.match(/^# edition: (\w+)$/m) : null;
  return {
    ok: true,
    file,
    hasBlock,
    edition: editionMatch ? normalizeEdition(editionMatch[1]) : hasBlock ? "standard" : null,
    complete: hasBlock && ["sandbox-policy", "user-approval", "permission", "system-prompt"].every((id) => body.includes(`- id: ${id}`)),
    bytes: Buffer.byteLength(text),
  };
}

export function applyProfile({ dir, edition = "standard", dry = false }) {
  const info = inspectProfile({ dir });
  if (!info.ok) return info;
  const before = fs.readFileSync(info.file);
  const text = before.toString("utf8");
  const next = Buffer.from(upsert(text, edition), "utf8");
  if (next.equals(before)) return { ok: true, dry, changed: 0, file: info.file, edition: normalizeEdition(edition) };
  if (dry) return { ok: true, dry: true, changed: 1, file: info.file, edition: normalizeEdition(edition) };

  const backupDir = path.join(storeDir(), "backups", `profile-${sha256(info.file).slice(0, 16)}`);
  fs.mkdirSync(backupDir, { recursive: true });
  const backup = path.join(backupDir, "cordis.patch.yml.bak");
  if (!fs.existsSync(backup)) fs.writeFileSync(backup, before);
  writeAtomic(info.file, next);

  const ledger = readLedger();
  ledger[info.file] = {
    file: info.file,
    backup,
    sha256Before: sha256(fs.readFileSync(backup)),
    sha256After: sha256(next),
    appliedAt: new Date().toISOString(),
    edition: normalizeEdition(edition),
  };
  writeLedger(ledger);
  return { ok: true, dry: false, changed: 1, file: info.file, edition: normalizeEdition(edition) };
}

export function revertProfile({ dir, dry = false } = {}) {
  const ledger = readLedger();
  const ids = Object.keys(ledger);
  if (ids.length === 0) return { ok: true, changed: 0, results: [] };
  const results = [];
  let changed = 0;
  for (const key of ids) {
    const entry = ledger[key];
    if (!fs.existsSync(entry.backup)) {
      results.push({ file: entry.file, state: "backup-missing" });
      continue;
    }
    const original = fs.readFileSync(entry.backup);
    if (sha256(original) !== entry.sha256Before) {
      results.push({ file: entry.file, state: "backup-corrupt" });
      continue;
    }
    if (!dry) {
      writeAtomic(entry.file, original);
      delete ledger[key];
    }
    changed += 1;
    results.push({ file: entry.file, state: "restored" });
  }
  if (!dry) writeLedger(ledger);
  return { ok: true, dry, changed, results };
}
