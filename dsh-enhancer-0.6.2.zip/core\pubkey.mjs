// 出货包内嵌的授权公钥（Ed25519 / SPKI PEM）。
// 私钥只在发行方本机：~/.dsh-enhancer-vendor/vendor-private.pem，不进任何交付物。
export const PUBLIC_KEY_PEM = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAkAdXUUHF6hLs87M8gqfG/+11ptVuaTXixhvBjcLbcoU=
-----END PUBLIC KEY-----
`;

export const KEY_FINGERPRINT = "k1:17BC217E";
