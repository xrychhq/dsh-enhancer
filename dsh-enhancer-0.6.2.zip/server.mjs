import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { apply, revert, doctor, inspect, locate, updateStatus, storeDir } from "./core/patcher.mjs";
import { applyProfile, revertProfile, inspectProfile } from "./core/profile.mjs";
import { verify as verifyLicense, allowedMachines, machineId, fingerprint, resolvePublicKey, editionOf } from "./core/license.mjs";
import { fetchSignedRevocations, verifySignedRevocations } from "./core/revocations.mjs";
import { readCachedPayload, writeCachedPayload } from "./core/revocation-cache.mjs";
import { mergeRemote, clearRemote, remoteSize } from "./core/revoked.mjs";
import { checkRemote } from "./core/updates.mjs";
import { fetchPackage, stage, readPending, applyPending } from "./core/update.mjs";
import { runDiagnose } from "./core/diag.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const UI = path.join(here, "ui", "index.html");

function json(res, code, body) {
  const buf = Buffer.from(JSON.stringify(body));
  res.writeHead(code, {
    "content-type": "application/json; charset=utf-8",
    "content-length": buf.length,
    "cache-control": "no-store",
  });
  res.end(buf);
}

async function readBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 1 << 20) throw new Error("body-too-large");
    chunks.push(chunk);
  }
  if (size === 0) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function profileDir() {
  return process.env.DSH_ENHANCER_PROFILE_DIR || process.env.DSH_PROFILE_DIR || null;
}

function productVersion() {
  try {
    return JSON.parse(fs.readFileSync(path.join(here, "package.json"), "utf8")).version ?? "0.0.0";
  } catch {
    return "0.0.0";
  }
}

function licensePath() {
  return process.env.DSH_ENHANCER_LICENSE || path.join(storeDir(), "license.key");
}

function licenseState() {
  const machine = machineId();
  const keyPath = licensePath();
  const base = { machine, fingerprint: fingerprint(), keyPath };
  if (!fs.existsSync(keyPath)) return { ...base, valid: false, reason: "no-license", edition: "standard" };
  try {
    const token = fs.readFileSync(keyPath, "utf8").trim();
    const result = verifyLicense({ token, machine });
    return {
      ...base,
      valid: result.ok,
      reason: result.reason ?? null,
      plan: result.payload?.plan ?? null,
      subject: result.payload?.subject ?? null,
      exp: result.payload?.exp ?? null,
      seats: result.payload?.seats ?? null,
      allowed: allowedMachines(result.payload).length,
      edition: result.ok ? editionOf(result.payload?.plan) : "standard",
    };
  } catch (error) {
    return { ...base, valid: false, reason: "license-unreadable", error: String(error), edition: "standard" };
  }
}

/** 当前授权允许的功能版本；无授权按 standard。 */
function currentEdition() {
  const state = licenseState();
  return state.valid ? state.edition : "standard";
}

function importLicense(token) {
  const machine = machineId();
  const result = verifyLicense({ token, machine });
  if (!result.ok) return { ok: false, reason: result.reason };
  const target = licensePath();
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, `${token.trim()}\n`);
  return { ok: true, ...licenseState() };
}

export async function refreshRevocations() {
  const url = process.env.DSH_ENHANCER_REVOCATION_URL;
  if (!url) return { ok: false, state: "unconfigured" };

  const store = storeDir();
  const online = await fetchSignedRevocations({ url, publicKeyPem: resolvePublicKey() });

  if (online.ok) {
    if (online.raw) writeCachedPayload(store, online.raw);
    const added = mergeRemote(online.ids);
    return { ok: true, state: "merged", added, count: online.count, expires: online.expires, version: online.version, source: "network" };
  }

  const cached = readCachedPayload(store);
  if (!cached) return { ok: false, state: "unavailable", reason: online.reason ?? online.state, source: "none" };

  const verified = verifySignedRevocations({ payload: cached, publicKeyPem: resolvePublicKey() });
  if (!verified.ok) return { ok: false, state: "unavailable", reason: online.reason ?? online.state, source: "cache", cacheState: verified.reason };
  const added = mergeRemote(verified.ids);
  return {
    ok: true,
    state: "merged",
    added,
    count: verified.count,
    expires: verified.expires,
    version: verified.version,
    source: "cache",
    cachedAt: cached.cachedAt,
    onlineReason: online.reason ?? online.state,
  };
}

export function startServer({ token = crypto.randomBytes(16).toString("hex"), port = 0, root } = {}) {
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url ?? "/", "http://127.0.0.1");
    try {
      if (req.method === "GET" && url.pathname === "/") {
        const html = fs.readFileSync(UI, "utf8").replace(/__TOKEN__/g, token);
        res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
        return res.end(html);
      }
      if (!url.pathname.startsWith("/api/")) return json(res, 404, { ok: false, reason: "no-route" });
      if (req.headers["x-token"] !== token) return json(res, 403, { ok: false, reason: "bad-token" });

      if (req.method === "GET" && url.pathname === "/api/state") return json(res, 200, inspect({ root }));
      if (req.method === "GET" && url.pathname === "/api/doctor") return json(res, 200, doctor({ root }));
      if (req.method === "GET" && url.pathname === "/api/diag") return json(res, 200, await runDiagnose({ root }));
      if (req.method === "GET" && url.pathname === "/api/update") {
        const located = locate({ root });
        if (!located.ok) return json(res, 200, located);
        return json(res, 200, { ok: true, ...updateStatus(located), install: { root: located.root, version: located.version } });
      }
      if (req.method === "GET" && url.pathname === "/api/license") return json(res, 200, { ok: true, ...licenseState() });
      if (req.method === "GET" && url.pathname === "/api/update/pending") return json(res, 200, { ok: true, pending: readPending(storeDir()) });
      if (req.method === "POST" && url.pathname === "/api/update/fetch") {
        const body = await readBody(req);
        const fetched = await fetchPackage({
          url: body.url,
          sha256: body.sha256 ?? null,
          dir: path.join(storeDir(), "updates"),
        });
        if (!fetched.ok) return json(res, 200, fetched);
        const staged = stage({
          storeDir: storeDir(),
          file: fetched.file,
          version: body.version ?? null,
          sha256: fetched.sha256,
          appDir: here,
        });
        return json(res, 200, { ...staged, bytes: fetched.bytes });
      }
      if (req.method === "POST" && url.pathname === "/api/update/apply") {
        const result = applyPending({ storeDir: storeDir(), appDir: here });
        return json(res, 200, { ...result, restartRequired: result.state === "applied" });
      }
      if (req.method === "GET" && url.pathname === "/api/revocation") return json(res, 200, { ok: true, source: process.env.DSH_ENHANCER_REVOCATION_URL ?? null, remote: remoteSize(), embedded: 0 });
      if (req.method === "POST" && url.pathname === "/api/revocation/refresh") return json(res, 200, await refreshRevocations());
      if (req.method === "GET" && url.pathname === "/api/check") {
        const result = await checkRemote({
          url: process.env.DSH_ENHANCER_UPDATE_URL,
          current: productVersion(),
          timeoutMs: Number(process.env.DSH_ENHANCER_CHECK_TIMEOUT ?? 4000),
        });
        return json(res, 200, { ...result, current: productVersion() });
      }
      if (req.method === "POST" && url.pathname === "/api/license/import") {
        const body = await readBody(req);
        if (typeof body.token !== "string" || body.token.length > 4096) return json(res, 200, { ok: false, reason: "bad-token" });
        return json(res, 200, importLicense(body.token));
      }

      if (url.pathname.startsWith("/api/profile")) {
        const dir = profileDir();
        if (!dir) return json(res, 200, { ok: false, reason: "profile-dir-unknown" });
        if (req.method === "GET" && url.pathname === "/api/profile") return json(res, 200, inspectProfile({ dir }));
        if (req.method === "POST" && url.pathname === "/api/profile/apply") {
          const body = await readBody(req);
          return json(res, 200, applyProfile({ dir, edition: currentEdition(), dry: Boolean(body.dry) }));
        }
        if (req.method === "POST" && url.pathname === "/api/profile/revert") {
          const body = await readBody(req);
          return json(res, 200, revertProfile({ dir, dry: Boolean(body.dry) }));
        }
      }

      if (req.method === "POST" && url.pathname === "/api/apply") {
        const body = await readBody(req);
        return json(res, 200, apply({ root, ids: body.ids, dry: Boolean(body.dry) }));
      }
      if (req.method === "POST" && url.pathname === "/api/revert") {
        const body = await readBody(req);
        return json(res, 200, revert({ dry: Boolean(body.dry) }));
      }
      return json(res, 404, { ok: false, reason: "no-route" });
    } catch (error) {
      return json(res, 500, { ok: false, reason: "server-error", error: String(error) });
    }
  });

  return new Promise((resolve) => {
    server.listen(port, "127.0.0.1", async () => {
      const actual = server.address().port;
      if (process.env.DSH_ENHANCER_REVOCATION_URL) {
        try {
          const r = await refreshRevocations();
          if (r.ok) console.log(`revocations merged: ${r.added} new (total ${remoteSize()})`);
          else console.log(`revocations unavailable: ${r.reason ?? r.state}`);
        } catch (error) {
          console.log(`revocations fetch failed: ${String(error?.name ?? error)}`);
        }
      }
      resolve({
        server,
        port: actual,
        token,
        url: `http://127.0.0.1:${actual}/?t=${token}`,
        close: () => new Promise((done) => server.close(done)),
      });
    });
  });
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const port = Number(process.env.DSH_ENHANCER_PORT ?? 0);
  const token = process.env.DSH_ENHANCER_TOKEN || crypto.randomBytes(16).toString("hex");
  startServer({ port, token }).then(({ url }) => {
    console.log(`DSH 增强器  ${url}`);
    console.log(`token  ${token}`);
    console.log(`store  ${storeDir()}`);
  });
}
