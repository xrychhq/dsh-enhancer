import crypto from "node:crypto";

export const REV_FETCH_TIMEOUT = 4000;

export async function fetchSignedRevocations({ url, publicKeyPem, timeoutMs = REV_FETCH_TIMEOUT } = {}) {
  if (!url) return { ok: false, reason: "no-url" };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal, headers: { "cache-control": "no-cache" } });
    if (!res.ok) return { ok: false, reason: "http-error", status: res.status };
    const payload = await res.json();
    return { ...verifySignedRevocations({ payload, publicKeyPem }), raw: payload };
  } catch (error) {
    return { ok: false, reason: "unreachable", error: String(error?.name ?? error) };
  } finally {
    clearTimeout(timer);
  }
}

export function verifySignedRevocations({ payload, publicKeyPem }) {
  if (!payload || typeof payload !== "object") return { ok: false, reason: "malformed" };
  const { head, sig } = payload;
  if (typeof head !== "string" || typeof sig !== "string") return { ok: false, reason: "malformed" };
  let parsed;
  try { parsed = JSON.parse(Buffer.from(head, "base64").toString("utf8")); } catch { return { ok: false, reason: "malformed" }; }
  let verified = false;
  try {
    verified = crypto.verify(null, Buffer.from(head, "base64"), crypto.createPublicKey(publicKeyPem), Buffer.from(sig, "base64"));
  } catch { return { ok: false, reason: "bad-public-key" }; }
  if (!verified) return { ok: false, reason: "bad-signature" };
  const now = Math.floor(Date.now() / 1000);
  if (typeof parsed.exp !== "number" || parsed.exp <= now) return { ok: false, reason: "expired" };
  const ids = Array.isArray(parsed.ids) ? parsed.ids : [];
  return { ok: true, ids, version: parsed.version ?? null, expires: parsed.exp, count: ids.length };
}

export function signRevocations({ privateKeyPem, ids, version, days = 30, now = Date.now() }) {
  const payload = { ids: [...new Set(ids.map((i) => String(i).trim().toUpperCase()).filter(Boolean))], version: version ?? "1", exp: Math.floor(now / 1000) + days * 86400 };
  const head = Buffer.from(JSON.stringify(payload)).toString("base64");
  const sig = crypto.sign(null, Buffer.from(head, "base64"), crypto.createPrivateKey(privateKeyPem)).toString("base64");
  return { head, sig, payload };
}
