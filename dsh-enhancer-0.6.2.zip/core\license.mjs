import crypto from "node:crypto";
import os from "node:os";
import { PUBLIC_KEY_PEM } from "./pubkey.mjs";
import { isRevoked } from "./revoked.mjs";

const b64url = (buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64url = (s) => Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/"), "base64");

// 虚拟网卡随 VPN / 虚拟机 / WSL 增减，不能参与机器指纹，否则装个 tailscale 授权就废了
const VIRTUAL_NIC = /vethernet|vmware|virtualbox|vbox|hyper-?v|tailscale|tap[-_]|zerotier|radmin|warp|loopback|bluetooth|docker|npcap/i;

// 网卡名是本地化的（中文系统叫「以太网 2」），按名称拦不住，再加一层 MAC 前缀过滤
const VIRTUAL_OUI = /^(0a0027|080027|005056|000c29|000569|001c14|00155d|02004c4f4f50|00ff|0250f2|0a0027)/i;

const isRealMac = (mac) => !VIRTUAL_OUI.test(mac.replace(/:/g, ""));

function primaryMac() {
  const macs = new Set();
  for (const [name, list] of Object.entries(os.networkInterfaces() ?? {})) {
    if (VIRTUAL_NIC.test(name)) continue;
    for (const nic of list ?? []) {
      if (!nic.mac || nic.mac === "00:00:00:00:00:00" || nic.internal) continue;
      if (!isRealMac(nic.mac)) continue;
      macs.add(nic.mac.toLowerCase());
    }
  }
  // 排序消除枚举顺序依赖：同一台机器无论网卡顺序如何都得到同一个值
  return [...macs].sort()[0] ?? "no-mac";
}

/**
 * 机器指纹。
 * 只用硬件与系统特征，不含 hostname（改名会导致授权失效）。
 * 网卡增减仍会改变指纹，这属于换机范畴，按换机重签处理。
 */
export function machineId() {
  const seed = [os.platform(), os.arch(), os.cpus()[0]?.model ?? "", primaryMac()].join("|");
  return crypto.createHash("sha256").update(seed).digest("hex").slice(0, 16).toUpperCase();
}

export function resolvePublicKey() {
  return process.env.DSH_ENHANCER_PUBKEY || PUBLIC_KEY_PEM;
}

export function fingerprint(publicKeyPem = resolvePublicKey()) {
  return crypto.createHash("sha256").update(publicKeyPem).digest("hex").slice(0, 8).toUpperCase();
}

export function generateKeypair() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync("ed25519");
  return {
    publicKeyPem: publicKey.export({ type: "spki", format: "pem" }),
    privateKeyPem: privateKey.export({ type: "pkcs8", format: "pem" }),
  };
}

/**
 * 签发授权。days 为 null / 0 时签永久授权（payload 不带 exp）。
 * 永久授权不等于免费维护：适配新的 DSH 大版本仍需出新的工具版本。
 */
export function issue({ privateKeyPem, plan = "standard", subject = "", days = null, machine = null, machines = null, now = Date.now() }) {
  const list = machines?.length ? [...new Set(machines)] : [machine ?? "*"];
  const issued = Math.floor(now / 1000);
  const payload = {
    plan,
    subject,
    machines: list,
    seats: list.includes("*") ? null : list.length,
    iat: issued,
  };
  if (Number.isFinite(days) && days > 0) payload.exp = issued + days * 86400;
  const head = b64url(JSON.stringify(payload));
  const sig = crypto.sign(null, Buffer.from(head), crypto.createPrivateKey(privateKeyPem));
  return `${head}.${b64url(sig)}`;
}

export function allowedMachines(payload) {
  if (!payload) return [];
  if (Array.isArray(payload.machines)) return payload.machines;
  if (typeof payload.machine === "string") return [payload.machine];
  return [];
}

/** 授权档位 → 功能版本。standard 只解锁补丁；reverse/pro 额外写入逆向规则。 */
export function editionOf(plan) {
  const value = String(plan ?? "").toLowerCase();
  if (value === "reverse" || value === "pro" || value === "reverse-pro") return "reverse";
  return "standard";
}

export function verify({ token, publicKeyPem = resolvePublicKey(), machine = machineId(), now = Date.now() }) {
  if (typeof token !== "string" || !token.includes(".")) return { ok: false, reason: "malformed" };
  const [head, sigPart] = token.split(".");
  let payload;
  try {
    payload = JSON.parse(unb64url(head).toString("utf8"));
  } catch {
    return { ok: false, reason: "malformed" };
  }
  let verified = false;
  try {
    verified = crypto.verify(null, Buffer.from(head), crypto.createPublicKey(publicKeyPem), unb64url(sigPart));
  } catch {
    return { ok: false, reason: "bad-public-key" };
  }
  if (!verified) return { ok: false, reason: "bad-signature" };
  if (isRevoked(token)) return { ok: false, reason: "revoked", payload };
  // 无 exp 字段 = 永久授权，跳过过期检查
  if (typeof payload.exp === "number" && payload.exp * 1000 <= now) return { ok: false, reason: "expired", payload };
  const allowed = allowedMachines(payload);
  if (!allowed.includes("*") && !allowed.includes(machine)) return { ok: false, reason: "machine-mismatch", payload };
  return { ok: true, payload };
}
