const parse = (v) => v.split(/[.+-]/).map((part) => (/^\d+$/.test(part) ? Number(part) : part));

export function compareVersions(a, b) {
  const left = parse(String(a));
  const right = parse(String(b));
  const size = Math.max(left.length, right.length);
  for (let i = 0; i < size; i += 1) {
    const x = left[i] ?? 0;
    const y = right[i] ?? 0;
    if (typeof x === "number" && typeof y === "number") {
      if (x !== y) return x > y ? 1 : -1;
      continue;
    }
    const sx = String(x);
    const sy = String(y);
    if (sx !== sy) return sx > sy ? 1 : -1;
  }
  return 0;
}

export async function checkRemote({ url, current, timeoutMs = 4000 }) {
  if (!url) return { ok: true, state: "unconfigured" };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal, headers: { "cache-control": "no-cache" } });
    if (!res.ok) return { ok: false, state: "http-error", status: res.status };
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return { ok: false, state: "bad-manifest" };
    }
    if (typeof data?.version !== "string") return { ok: false, state: "bad-manifest" };
    return {
      ok: true,
      state: compareVersions(data.version, current) > 0 ? "newer" : "up-to-date",
      remote: data.version,
      current,
      download: data.url ?? null,
      sha256: data.sha256 ?? null,
      notes: data.notes ?? null,
    };
  } catch (error) {
    return { ok: false, state: "unreachable", error: String(error?.name ?? error) };
  } finally {
    clearTimeout(timer);
  }
}
