import crypto from "node:crypto";

// 运行时装载的吊销指纹表（合并内嵌常量 + env + 远程签清单）。
// REVOKED 在模块初始化时为空，运行时可由 revocations.mjs 合并进来。
export const REVOKED = [];
const _set = new Set(REVOKED);

const normalize = (list) => list.map((id) => String(id).trim().toUpperCase()).filter(Boolean);

export function revokedList() {
  const extra = (process.env.DSH_ENHANCER_REVOKED ?? "").split(",");
  return [...normalize([..._set]), ...normalize(extra)];
}

export function mergeRemote(ids) {
  let added = 0;
  for (const id of normalize(ids ?? [])) {
    if (!_set.has(id)) {
      _set.add(id);
      REVOKED.push(id);
      added += 1;
    }
  }
  return added;
}

export function clearRemote() {
  let removed = 0;
  for (const id of _set) {
    const idx = REVOKED.indexOf(id);
    if (idx >= 0) REVOKED.splice(idx, 1);
    removed += 1;
  }
  _set.clear();
  return removed;
}

export function remoteSize() {
  return _set.size;
}

export function tokenId(token) {
  return crypto.createHash("sha256").update(String(token)).digest("hex").slice(0, 16).toUpperCase();
}

export function isRevoked(token) {
  return revokedList().includes(tokenId(token));
}
