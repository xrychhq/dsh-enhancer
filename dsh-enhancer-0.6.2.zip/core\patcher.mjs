import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import crypto from "node:crypto";
import { FILE_PATCHES, PROFILE_ROWS, TARGET_VERSION } from "./patches.mjs";

const sha256 = (buf) => crypto.createHash("sha256").update(buf).digest("hex");
const isFile = (p) => {
  try {
    return fs.statSync(p).isFile();
  } catch {
    return false;
  }
};

export function storeDir() {
  return process.env.DSH_ENHANCER_HOME || path.join(os.homedir(), "AppData", "Local", "DSHEnhancer");
}

export function ledgerPath() {
  return path.join(storeDir(), "ledger.json");
}

function stateFile() {
  return path.join(storeDir(), "installs.json");
}

function readState() {
  try {
    return JSON.parse(fs.readFileSync(stateFile(), "utf8"));
  } catch {
    return {};
  }
}

function writeState(state) {
  fs.mkdirSync(storeDir(), { recursive: true });
  const tmp = `${stateFile()}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
  fs.renameSync(tmp, stateFile());
}

const stateKey = (loc) => sha256(loc.root).slice(0, 16);

export function recordInstall(loc, ids) {
  const state = readState();
  const key = stateKey(loc);
  const prev = state[key] ?? {};
  state[key] = {
    root: loc.root,
    version: loc.version,
    loader: loc.loader,
    patches: [...new Set([...(prev.patches ?? []), ...ids])],
    firstPatchedAt: prev.firstPatchedAt ?? new Date().toISOString(),
    lastPatchedAt: new Date().toISOString(),
  };
  writeState(state);
  return state[key];
}

export function updateStatus(loc) {
  const rec = readState()[stateKey(loc)] ?? null;
  if (!rec) return { state: "never-patched", current: loc.version, recorded: null };
  if (loc.loader === "asar") return { state: "asar-restored", current: loc.version, recorded: rec.version };
  if (rec.version !== loc.version) return { state: "version-changed", current: loc.version, recorded: rec.version };
  return { state: "current", current: loc.version, recorded: rec.version, lastPatchedAt: rec.lastPatchedAt };
}

function candidateRoots() {
  const roots = [];
  if (process.env.DSH_INSTALL_ROOT) roots.push(process.env.DSH_INSTALL_ROOT);
  const local = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
  roots.push(path.join(local, "Programs", "DeepSeek Harness"));
  roots.push(path.join(process.env.ProgramFiles || "C:\\Program Files", "DeepSeek Harness"));
  return [...new Set(roots)];
}

export function locate({ root } = {}) {
  const searched = root ? [root] : candidateRoots();
  for (const candidate of searched) {
    const appDir = path.join(candidate, "resources", "app");
    const dshDir = path.join(appDir, "dsh");
    if (!fs.existsSync(dshDir)) continue;
    let version = null;
    try {
      const raw = fs.readFileSync(path.join(appDir, "package.json"), "utf8").replace(/^\uFEFF/, "");
      version = JSON.parse(raw).version ?? null;
    } catch {
      version = null;
    }
    return {
      ok: true,
      root: path.resolve(candidate),
      appDir,
      dshDir,
      version,
      loader: fs.existsSync(path.join(candidate, "resources", "app.asar")) ? "asar" : "unpacked",
      compatible: version === TARGET_VERSION,
    };
  }
  return { ok: false, reason: "install-not-found", searched };
}

export function targetFile(loc, patch) {
  return path.join(loc.dshDir, "node_modules", "@deepseek-ai", patch.pkg, patch.rel);
}

function relPath(loc, file) {
  return path.relative(loc.root, file).split(path.sep).join("/");
}

export function inspectPatch(text, patch) {
  const anchorsGone = patch.steps.every((s) => !s.find || !text.includes(s.find));
  const verified = (patch.verify ?? []).every((n) => text.includes(n));
  const cleaned = (patch.gone ?? []).every((n) => !text.includes(n));
  const rewritten = patch.steps.every((s) => s.find === "" || text.includes(s.replace));
  if (anchorsGone && verified && cleaned && rewritten) return "applied";
  if (patch.steps.some((s) => text.includes(s.find))) return "actionable";
  return "anchor-missing";
}

function rewrite(text, patch) {
  let out = text;
  for (const step of patch.steps) {
    const at = out.indexOf(step.find);
    if (at < 0) return { ok: false, error: "anchor-missing", needle: step.find.slice(0, 72) };
    out =
      step.all && step.find.length > 0
        ? out.split(step.find).join(step.replace)
        : out.slice(0, at) + step.replace + out.slice(at + step.find.length);
  }
  for (const needle of patch.verify ?? [])
    if (!out.includes(needle)) return { ok: false, error: "verify-failed", needle: needle.slice(0, 72) };
  for (const needle of patch.gone ?? [])
    if (out.includes(needle)) return { ok: false, error: "gone-failed", needle: needle.slice(0, 72) };
  return { ok: true, text: out };
}

function writeAtomic(file, buf) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, buf);
  fs.renameSync(tmp, file);
}

function readLedger() {
  try {
    const parsed = JSON.parse(fs.readFileSync(ledgerPath(), "utf8"));
    return {
      root: parsed.root ?? null,
      updatedAt: parsed.updatedAt ?? null,
      seq: parsed.seq ?? 0,
      entries: parsed.entries ?? {},
    };
  } catch {
    return { root: null, updatedAt: null, seq: 0, entries: {} };
  }
}

function writeLedger(ledger) {
  fs.mkdirSync(storeDir(), { recursive: true });
  const tmp = `${ledgerPath()}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(ledger, null, 2));
  fs.renameSync(tmp, ledgerPath());
}

export function inspect({ root } = {}) {
  const loc = locate({ root });
  if (!loc.ok) return loc;
  const ledger = readLedger();
  const patches = FILE_PATCHES.map((patch) => {
    const file = targetFile(loc, patch);
    const present = isFile(file);
    const state = present ? inspectPatch(fs.readFileSync(file, "utf8"), patch) : "missing-file";
    return {
      id: patch.id,
      name: patch.name,
      file: relPath(loc, file),
      state,
      recorded: Boolean(ledger.entries[patch.id]),
    };
  });
  return {
    ok: true,
    install: loc,
    patches,
    ledger: { updatedAt: ledger.updatedAt, count: Object.keys(ledger.entries).length },
    profileRows: PROFILE_ROWS.split(/\n(?=- id: )/).length,
  };
}

export function apply({ root, ids, dry = false } = {}) {
  const loc = locate({ root });
  if (!loc.ok) return loc;
  const wanted = ids?.length ? new Set(ids) : null;
  const selected = FILE_PATCHES.filter((p) => !wanted || wanted.has(p.id));
  const ledger = readLedger();
  const overlay = new Map();
  const originals = new Map();
  const results = [];
  let seq = ledger.seq;
  let changed = 0;

  const current = (file) => overlay.get(file) ?? fs.readFileSync(file).toString("utf8");

  try {
    for (const patch of selected) {
      const file = targetFile(loc, patch);
      if (!isFile(file)) {
        results.push({ id: patch.id, state: "missing-file" });
        continue;
      }
      const text = current(file);
      if (inspectPatch(text, patch) === "applied") {
        results.push({ id: patch.id, state: "already" });
        continue;
      }
      const step = rewrite(text, patch);
      if (!step.ok) {
        results.push({ id: patch.id, state: "failed", error: step.error, needle: step.needle });
        continue;
      }
      if (!dry) {
        const before = Buffer.from(text, "utf8");
        if (!originals.has(file)) originals.set(file, before);
        const backupDir = path.join(storeDir(), "backups", sha256(file).slice(0, 16));
        fs.mkdirSync(backupDir, { recursive: true });
        const backup = path.join(backupDir, `${patch.id}.bak`);
        fs.writeFileSync(backup, before);
        const after = Buffer.from(step.text, "utf8");
        writeAtomic(file, after);
        seq += 1;
        ledger.entries[patch.id] = {
          seq,
          file,
          rel: relPath(loc, file),
          backup,
          sha256Before: sha256(before),
          sha256After: sha256(after),
          version: loc.version,
          appliedAt: new Date().toISOString(),
        };
      }
      overlay.set(file, step.text);
      changed += 1;
      results.push({ id: patch.id, state: "applied" });
    }
  } catch (error) {
    for (const [file, buf] of originals) {
      try {
        writeAtomic(file, buf);
      } catch {}
    }
    return { ok: false, reason: "apply-failed-rolled-back", error: String(error), results, install: loc };
  }

  if (changed > 0 && !dry) {
    ledger.root = loc.root;
    ledger.seq = seq;
    ledger.updatedAt = new Date().toISOString();
    writeLedger(ledger);
    recordInstall(loc, results.filter((r) => r.state === "applied").map((r) => r.id));
  }
  return { ok: true, dry, results, changed, install: loc };
}

export function revert({ dry = false } = {}) {
  const ledger = readLedger();
  const entries = Object.entries(ledger.entries)
    .map(([id, entry]) => ({ id, entry }))
    .sort((a, b) => (b.entry.seq ?? 0) - (a.entry.seq ?? 0));
  if (entries.length === 0) return { ok: true, results: [], changed: 0 };

  const staging = [];
  const results = [];
  for (const { id, entry } of entries) {
    if (!isFile(entry.backup)) {
      results.push({ id, state: "backup-missing" });
      continue;
    }
    const original = fs.readFileSync(entry.backup);
    if (sha256(original) !== entry.sha256Before) {
      results.push({ id, state: "backup-corrupt" });
      continue;
    }
    staging.push({ id, entry, original });
    results.push({ id, state: "restorable" });
  }
  if (dry) return { ok: true, dry: true, results, changed: staging.length };

  for (const item of staging) {
    writeAtomic(item.entry.file, item.original);
    if (sha256(fs.readFileSync(item.entry.file)) !== item.entry.sha256Before)
      return { ok: false, reason: "revert-verify-failed", id: item.id };
    delete ledger.entries[item.id];
  }
  ledger.updatedAt = new Date().toISOString();
  writeLedger(ledger);
  return { ok: true, results, changed: staging.length };
}

export function doctor({ root } = {}) {
  const report = inspect({ root });
  if (!report.ok) return report;
  const counts = report.patches.reduce((acc, p) => {
    acc[p.state] = (acc[p.state] ?? 0) + 1;
    return acc;
  }, {});
  const partial = (counts["anchor-missing"] ?? 0) + (counts["missing-file"] ?? 0) > 0;
  return {
    ok: true,
    verdict: !report.install.compatible ? "version-mismatch" : partial ? "partial" : "ready",
    target: TARGET_VERSION,
    install: {
      root: report.install.root,
      version: report.install.version,
      loader: report.install.loader,
      compatible: report.install.compatible,
    },
    counts,
    patches: report.patches,
    ledger: report.ledger,
    update: updateStatus({ root: report.install.root, version: report.install.version, loader: report.install.loader }),
    store: storeDir(),
  };
}

export { FILE_PATCHES, PROFILE_ROWS, TARGET_VERSION };
