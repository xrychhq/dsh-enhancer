import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { spawnSync } from "node:child_process";
import { locate, doctor, updateStatus, storeDir } from "./patcher.mjs";
import { remoteSize } from "./revoked.mjs";
import { fetchSignedRevocations } from "./revocations.mjs";
import { PUBLIC_KEY_PEM } from "./pubkey.mjs";

function listDshProcesses() {
  const result = spawnSync("tasklist", ["/FI", "IMAGENAME eq DeepSeek Harness.exe", "/FO", "CSV", "/NH"], { encoding: "utf8" });
  if (result.status !== 0) return { available: false, reason: "tasklist-failed", count: 0 };
  const lines = result.stdout.split(/\r?\n/).filter((line) => line.includes("DeepSeek Harness"));
  return { available: true, count: lines.length };
}

function detectLockFiles(root) {
  if (!root) return [];
  const dshDir = path.join(root, "resources", "app", "dsh");
  if (!fs.existsSync(dshDir)) return [];
  const findings = [];
  const out = spawnSync("cmd", ["/c", "dir", "/s", "/b", path.join(dshDir, "*~")], { encoding: "utf8" });
  if (out.status === 0)
    for (const line of out.stdout.split(/\r?\n/)) if (line.trim()) findings.push({ kind: "tilde-backup", path: line.trim() });
  return findings;
}

function edgeInfo() {
  const candidates = [
    process.env["ProgramFiles(x86)"] && path.join(process.env["ProgramFiles(x86)"], "Microsoft", "Edge", "Application", "msedge.exe"),
    process.env.ProgramFiles && path.join(process.env.ProgramFiles, "Microsoft", "Edge", "Application", "msedge.exe"),
  ].filter(Boolean);
  const found = candidates.find((candidate) => fs.existsSync(candidate));
  if (!found) return { available: false };
  const stat = fs.statSync(found);
  return { available: true, path: found, size: stat.size, mtime: stat.mtime.toISOString() };
}

export async function runDiagnose({ root = null, refresh = true } = {}) {
  const installed = locate({ root });
  const doc = installed.ok ? doctor({ root }) : { ok: false, reason: installed.reason };
  const locks = detectLockFiles(installed.ok ? installed.root : null);
  const dshProcess = listDshProcesses();
  const edge = edgeInfo();
  const licenseConfigured = fs.existsSync(path.join(storeDir(), "license.key"));
  const remote = remoteSize();

  let revocationFetch = null;
  const revocationUrl = process.env.DSH_ENHANCER_REVOCATION_URL;
  if (refresh && revocationUrl)
    revocationFetch = await fetchSignedRevocations({ url: revocationUrl, publicKeyPem: PUBLIC_KEY_PEM });

  const summary = {
    installFound: installed.ok,
    loader: installed.ok ? installed.loader : null,
    versionMatch: installed.ok ? installed.compatible : false,
    pendingPatches: doc?.counts?.actionable ?? 0,
    asarRestored: installed.ok ? updateStatus(installed).state === "asar-restored" : false,
    dshRunning: dshProcess.count > 0,
    lockFiles: locks.length,
    edgeAvailable: edge.available,
    licenseConfigured,
    remoteRevocations: remote,
    revocationSource: revocationUrl ?? null,
    revocationState: revocationFetch ? (revocationFetch.ok ? "ok" : revocationFetch.reason) : "unconfigured",
  };

  return {
    generatedAt: new Date().toISOString(),
    app: { version: productVersion(), node: process.versions.node, platform: process.platform, arch: process.arch },
    summary,
    install: installed,
    doctor: doc,
    locks,
    dshProcess,
    edge,
    license: { configured: licenseConfigured, remote },
  };
}

function productVersion() {
  try {
    return JSON.parse(fs.readFileSync(new URL("../package.json", import.meta.url), "utf8")).version ?? "0.0.0";
  } catch {
    return "0.0.0";
  }
}

export function summarize(diag) {
  const s = diag.summary;
  return [
    `版本      ${diag.app.version}  node ${diag.app.node}  ${diag.app.platform}/${diag.app.arch}`,
    `安装      ${s.installFound ? `找到 ${diag.install.version}  加载 ${s.loader}` : "未找到 DSH 安装"}`,
    `版本匹配  ${s.versionMatch ? "是" : "否"}`,
    `待打补丁  ${s.pendingPatches} 条  asar ${s.asarRestored ? "已回归" : "正常"}`,
    `DSH 进程  ${s.dshRunning ? "运行中" : "未运行"}  锁文件 ${s.lockFiles} 个`,
    `Edge      ${s.edgeAvailable ? "可用" : "不可用"}`,
    `授权      ${s.licenseConfigured ? "已导入" : "未导入"}  远程吊销 ${s.remoteRevocations} 条（${s.revocationState}）`,
  ].join("\n");
}

export function fingerprintOf(obj) {
  return crypto.createHash("sha256").update(JSON.stringify(obj)).digest("hex").slice(0, 12);
}