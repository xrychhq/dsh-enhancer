// injected by pack.mjs (do not edit)
export const UPDATE_URL = "";
export const REVOCATION_URL = "";
