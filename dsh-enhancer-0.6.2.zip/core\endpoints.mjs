// injected by pack.mjs (do not edit)
export const UPDATE_URL = "https://xrychhq.github.io/dsh-enhancer/latest.json";
export const REVOCATION_URL = "https://xrychhq.github.io/dsh-enhancer/revocations.json";
