import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { startServer } from "./server.mjs";
import { UPDATE_URL, REVOCATION_URL } from "./core/endpoints.mjs";

export function findEdge() {
  const candidates = [
    process.env["ProgramFiles(x86)"] && path.join(process.env["ProgramFiles(x86)"], "Microsoft", "Edge", "Application", "msedge.exe"),
    process.env.ProgramFiles && path.join(process.env.ProgramFiles, "Microsoft", "Edge", "Application", "msedge.exe"),
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, "Microsoft", "Edge", "Application", "msedge.exe"),
  ].filter(Boolean);
  return candidates.find((candidate) => fs.existsSync(candidate)) ?? null;
}

function writableDir(preferred) {
  const candidates = [
    preferred,
    process.env.DSH_ENHANCER_HOME,
    path.join(os.homedir(), "AppData", "Local", "DSHEnhancer"),
    path.join(os.homedir(), "Desktop", "DSHEnhancer"),
    path.join(os.tmpdir(), "DSHEnhancer"),
    path.join(os.homedir(), ".dsh-enhancer"),
  ].filter(Boolean);
  for (const candidate of candidates) {
    try {
      fs.mkdirSync(candidate, { recursive: true });
      const probe = path.join(candidate, ".w");
      fs.writeFileSync(probe, "1");
      fs.rmSync(probe);
      return candidate;
    } catch {}
  }
  return path.join(os.homedir(), ".dsh-enhancer");
}

async function main() {
  const appDir = path.dirname(fileURLToPath(import.meta.url));

  if (UPDATE_URL && !process.env.DSH_ENHANCER_UPDATE_URL) process.env.DSH_ENHANCER_UPDATE_URL = UPDATE_URL;
  if (REVOCATION_URL && !process.env.DSH_ENHANCER_REVOCATION_URL) process.env.DSH_ENHANCER_REVOCATION_URL = REVOCATION_URL;

  process.env.DSH_ENHANCER_HOME = writableDir(process.env.DSH_ENHANCER_HOME);
  console.log(`store  ${process.env.DSH_ENHANCER_HOME}`);

  try {
    const { applyPending } = await import("./core/update.mjs");
    const { storeDir } = await import("./core/patcher.mjs");
    const applied = applyPending({ storeDir: storeDir(), appDir });
    if (applied.state === "applied") console.log(`已应用暂存更新：${applied.files} 个文件（版本 ${applied.version ?? "未知"}）`);
    else if (applied.state !== "none") console.log(`暂存更新未应用：${applied.state}`);
  } catch (error) {
    console.log(`暂存更新跳过：${String(error?.message ?? error)}`);
  }

  const token = process.env.DSH_ENHANCER_TOKEN || crypto.randomBytes(16).toString("hex");
  const port = Number(process.env.DSH_ENHANCER_PORT ?? 0);
  const srv = await startServer({ token, port });
  const url = `http://127.0.0.1:${srv.port}/`;
  console.log(`地址   ${url}`);
  const edge = findEdge();
  const noWindow = process.env.DSH_ENHANCER_NO_WINDOW === "1";

  if (!edge) {
    console.log("未找到 Edge，请用浏览器打开上面的地址。");
    return;
  }
  if (noWindow) {
    console.log("未开窗口（NO_WINDOW=1）。");
    return;
  }

  const profile = path.join(os.tmpdir(), `dsh-enhancer-ui-${process.pid}`);
  try {
    const child = spawn(
      edge,
      [`--app=${url}`, `--user-data-dir=${profile}`, "--window-size=1240,940", "--no-first-run"],
      { stdio: "ignore", detached: false },
    );
    child.on("error", (error) => {
      console.log(`窗口启动失败：${error.message}`);
      console.log(`请手动用浏览器打开：${url}`);
    });
    child.on("exit", () => {
      void srv.close();
      try {
        fs.rmSync(profile, { recursive: true, force: true });
      } catch {}
      process.exit(0);
    });
    console.log("窗口已开。");
  } catch (error) {
    console.log(`窗口启动异常：${String(error?.message ?? error)}`);
    console.log(`请手动用浏览器打开：${url}`);
  }
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) await main();