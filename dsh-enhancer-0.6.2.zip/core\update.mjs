import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { readZip, isSafeName } from "./zip.mjs";

const sha256 = (buf) => crypto.createHash("sha256").update(buf).digest("hex");

export async function fetchPackage({ url, sha256: expected = null, dir, timeoutMs = 120000 }) {
  if (!url) return { ok: false, state: "no-url" };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return { ok: false, state: "http-error", status: res.status };
    const buf = Buffer.from(await res.arrayBuffer());
    const digest = sha256(buf);
    if (expected && digest !== String(expected).toLowerCase()) {
      return { ok: false, state: "sha-mismatch", expected, actual: digest };
    }
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `update-${digest.slice(0, 8)}.zip`);
    fs.writeFileSync(file, buf);
    return { ok: true, state: "downloaded", file, bytes: buf.length, sha256: digest };
  } catch (error) {
    return { ok: false, state: "unreachable", error: String(error?.name ?? error) };
  } finally {
    clearTimeout(timer);
  }
}

export function stage({ storeDir, file, version = null, sha256: digest = null, appDir = null }) {
  const pending = { file, version, sha256: digest, appDir, stagedAt: new Date().toISOString() };
  fs.mkdirSync(storeDir, { recursive: true });
  fs.writeFileSync(path.join(storeDir, "pending-update.json"), `${JSON.stringify(pending, null, 2)}\n`);
  return { ok: true, state: "staged", pending };
}

export function readPending(storeDir) {
  try {
    return JSON.parse(fs.readFileSync(path.join(storeDir, "pending-update.json"), "utf8"));
  } catch {
    return null;
  }
}

export function applyPending({ storeDir, appDir = null }) {
  const pending = readPending(storeDir);
  if (!pending) return { ok: true, state: "none" };
  const target = appDir ?? pending.appDir;
  if (!target) return { ok: false, state: "no-target" };
  if (!pending.file || !fs.existsSync(pending.file)) return { ok: false, state: "package-missing", file: pending.file ?? null };

  const buf = fs.readFileSync(pending.file);
  const digest = sha256(buf);
  if (pending.sha256 && digest !== pending.sha256) return { ok: false, state: "sha-mismatch" };

  let entries;
  try {
    entries = readZip(buf);
  } catch (error) {
    return { ok: false, state: "bad-zip", error: String(error?.message ?? error) };
  }
  for (const name of entries.keys()) if (!isSafeName(name)) return { ok: false, state: "unsafe-entry", name };

  const written = [];
  for (const [name, data] of entries) {
    const dest = path.join(target, name.split("/").join(path.sep));
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, data);
    written.push(name);
  }

  fs.rmSync(path.join(storeDir, "pending-update.json"), { force: true });
  fs.rmSync(pending.file, { force: true });
  return { ok: true, state: "applied", files: written.length, version: pending.version };
}
